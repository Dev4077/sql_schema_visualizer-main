import { TableNode } from "../Visualizer/components";

export const nodeTypes = {
  table: TableNode,
};
