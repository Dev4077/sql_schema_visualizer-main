import { Databases } from "../Visualizer/types";
import _databases from "./databases.json";

const databases = _databases as Databases;

export default databases;
