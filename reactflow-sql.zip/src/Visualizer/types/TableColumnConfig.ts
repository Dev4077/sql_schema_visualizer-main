export interface TableColumnConfig {
  name: string;
  description: string;
  type: string;
  handleType?: string;
  key?: boolean;
};
