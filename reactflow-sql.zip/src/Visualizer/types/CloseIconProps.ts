export type CloseIconProps = {
  className?: string,
  onClick?: Function
};
