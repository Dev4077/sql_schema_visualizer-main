import { Position } from "./Position";

export interface TablePositions {
  [tableName: string] : Position
};
