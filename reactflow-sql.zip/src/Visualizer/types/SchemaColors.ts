export interface SchemaColors {
  [schemaName: string] : string
};
